

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainController implements Initializable {
	 @FXML
	    private Button AdminLogin;

	  
	    
	@FXML
	 void viewvilla1(ActionEvent event) throws Exception {
		Parent pane = (ScrollPane) FXMLLoader.load(getClass().getResource("/VillaMainScene.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
	@FXML
	 void viewvilla2(ActionEvent event) throws Exception {
		Parent pane = (ScrollPane) FXMLLoader.load(getClass().getResource("/Villa2MainScene.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
	

	@FXML
	 void logbtn(ActionEvent event) throws Exception {
		Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/login.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}





import java.sql.*;
import java.util.ArrayList;
import java.util.Date;

public class Villa {
    private int villa_id;
    private boolean availability;
    private String description;
    private int owner_id;
    private Date reserv_date;
    private String v_name;
    private String city;
    private String street;
    private double price;

    public Villa(int villa_id, boolean availability, String description, int owner_id, Date reserv_date, String v_name, String city, String street, double price) {
        this.villa_id = villa_id;
        this.availability = availability;
        this.description = description;
        this.owner_id = owner_id;
        this.reserv_date = reserv_date;
        this.v_name = v_name;
        this.city = city;
        this.street = street;
        this.price = price;
    }

    public Connection getConnection() throws SQLException {
        Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/reserv","root","root1234");
        return connection;
    }

    public void addVilla(Villa villa) throws SQLException {
        Connection con = getConnection();
        String sql1 = "INSERT INTO villas (availability, discription, owner_id, reserv_date, v_name) VALUES (?, ?, ?,?,?)";
        PreparedStatement st1 = con.prepareStatement(sql1);
        st1.setBoolean(1, villa.isAvailability());
        st1.setString(2, villa.getDescription());
        st1.setInt(3, villa.getOwner_id());
        st1.setDate(4, (java.sql.Date) villa.getReserv_date());
        st1.setString(5, villa.getV_name());
        st1.executeUpdate();
        st1.close();

        String sql2 = "insert into villa_location(city, street, villa_id) values(?,?,?)";
        PreparedStatement st2 = con.prepareStatement(sql2);
        st2.setString(1,city);
        st2.setString(2,street);
        st2.setInt(3,villa_id);
        st2.close();

        String sql3 = "insert into price_per_night(price, villa_id) values(?,?)";
        PreparedStatement st3 = con.prepareStatement(sql3);
        st3.setDouble(1,price);
        st3.setInt(2,villa_id);
        con.close();
    }

    public void deleteVilla(Villa villa) throws SQLException {
        Connection con = getConnection();
        String sql = "delete from villas where villa_id = ?";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, villa_id);
        statement.close();
        con.close();
    }

    public ArrayList<Villa> getVillas() throws SQLException{
        ArrayList<Villa> villas = new ArrayList<Villa>();

        Connection con = getConnection();
            String sql = "SELECT v.villa_id, v.v_name, v.discription, v.availability, v.reserv_date, " +
                    "vl.street, vl.city, ppn.price " +
                    "FROM villas v " +
                    "JOIN villa_location vl ON v.villa_id = vl.villa_id " +
                    "JOIN price_per_night ppn ON v.villa_id = ppn.villa_id";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery(sql);

        while(rs.next()){
            int villa_id = rs.getInt("villa_id");
            String v_name = rs.getString("v_name");
            String discription = rs.getString("discription");
            boolean availability = rs.getBoolean("availability");
            Date reserv_date = rs.getDate("reserv_date");
            String street = rs.getString("street");
            String city = rs.getString("city");
            float price = rs.getFloat("price");

                villas.add(new Villa(villa_id, availability, discription, owner_id, reserv_date, v_name, city, street, price));
            }
        rs.close();
        st.close();
        con.close();
        return villas;
    }


    public int getVilla_id() {
        return villa_id;
    }

    public void setVilla_id(int villa_id) {
        this.villa_id = villa_id;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getOwner_id() {
        return owner_id;
    }

    public void setOwner_id(int owner_id) {
        this.owner_id = owner_id;
    }

    public Date getReserv_date() {
        return reserv_date;
    }

    public void setReserv_date(Date reserv_date) {
        this.reserv_date = reserv_date;
    }

    public String getV_name() {
        return v_name;
    }

    public void setV_name(String v_name) {
        this.v_name = v_name;
    }
}
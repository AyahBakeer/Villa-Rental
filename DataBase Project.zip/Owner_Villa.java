import javafx.scene.control.TableView;

public class Owner_Villa extends TableView<Owner_Villa> {
   private int Owner_ID;
   private int Villa_ID;
   private String owner_name;
   private int  owner_Phone_number;
   private String owner_email;

    public Owner_Villa(int Owner_ID, int Villa_ID, String owner_name, int owner_Phone_number, String owner_email) {
        this.Owner_ID=Owner_ID;
        this.Villa_ID=Villa_ID;
        this.owner_name=owner_name;
        this.owner_Phone_number=owner_Phone_number;
        this.owner_email=owner_email;
    }

    public int getOwner_ID() {
        return Owner_ID;
    }

    public void setOwner_ID(int owner_ID) {
        Owner_ID = owner_ID;
    }

    public int getVilla_ID() {
        return Villa_ID;
    }

    public void setVilla_ID(int villa_ID) {
        Villa_ID = villa_ID;
    }

    public String getOwner_name() {
        return owner_name;
    }

    public void setOwner_name(String owner_name) {
        this.owner_name = owner_name;
    }

    public int getOwner_Phone_number() {
        return owner_Phone_number;
    }

    public void setOwner_Phone_number(int owner_Phone_number) {
        this.owner_Phone_number = owner_Phone_number;
    }

    public String getOwner_email() {
        return owner_email;
    }

    public void setOwner_email(String owner_email) {
        this.owner_email = owner_email;
    }
}


import javafx.scene.control.TableView;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;

public class Villa_admin extends TableView<Villa_admin> {
    private int villa_id;
    private String villa_name;
    private String Location;
    private String description;
    private int max_number_of_people;
    private int number_of_bed;
    private int number_of_bathroom;
    private double price;

    public Villa_admin(int villa_id, String villa_name, String Location, String description,int max_number_of_people,int number_of_bed,int number_of_bathroom,double price ) {
        this.villa_id = villa_id;
        this.villa_name = villa_name;
        this.Location = Location;
        this.description = description;
        this.max_number_of_people=max_number_of_people;
        this.number_of_bed=number_of_bed;
        this.number_of_bathroom=number_of_bathroom;
        this.price = price;
    }

    public int getVilla_id() {
        return villa_id;
    }

    public void setVilla_id(int villa_id) {
        this.villa_id = villa_id;
    }

    public String getVilla_name() {
        return villa_name;
    }

    public void setVilla_name(String villa_name) {
        this.villa_name = villa_name;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public int getNumber_of_bed() {
        return number_of_bed;
    }

    public void setNumber_of_bed(int number_of_bed) {
        this.number_of_bed = number_of_bed;
    }

    public int getNumber_of_bathroom() {
        return number_of_bathroom;
    }

    public void setNumber_of_bathroom(int number_of_bathroom) {
        this.number_of_bathroom = number_of_bathroom;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public int getMax_number_of_people() {
        return max_number_of_people;
    }

    public void setMax_number_of_people(int max_number_of_people) {
        this.max_number_of_people = max_number_of_people;
    }
}
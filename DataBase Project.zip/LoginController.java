import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class LoginController implements Initializable {
	@FXML
	private RadioButton Adminselect;

	@FXML
	private RadioButton Guestsselect;


	@FXML
	private TextField password;

	@FXML
	private ToggleGroup select1;

	@FXML
	private TextField userid;

	@FXML
	private Hyperlink Guestssignup;

	static String ID;

	public void LogIn(ActionEvent event) throws Exception {
	if (Guestsselect.isSelected()) {
			Connection conn = DBConnecter.getConnection();
			String sql = "select * from login where Guests_iD= '" + userid.getText() + "'";
			Statement st = conn.createStatement();
			ResultSet result = st.executeQuery(sql);
			if (result.next()) {
				String userID = result.getString("Guests_iD");
				String pass = result.getString("password");
				if (userid.getText().equals(userID) && password.getText().equals(pass)) {
					Parent pane = (ScrollPane) FXMLLoader.load(getClass().getResource("/MainMainScene.fxml"));
					Scene scene = new Scene(pane);
					Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
					window.setScene(scene);
					window.show();
				} else {
					JOptionPane.showMessageDialog(null, "the username or passward is incorrect");
				}
			} else {
				JOptionPane.showMessageDialog(null, "there is an error");
			}

		} else if (Adminselect.isSelected()) {
			int id = Integer.parseInt(userid.getText());
			int pas = Integer.parseInt(password.getText());
			if ((id == 1 || id == 2 || id == 3) && (pas == 1234))
			{
				Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/details.fxml"));
				Scene scene = new Scene(pane);
				Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(scene);
		} else {
			JOptionPane.showMessageDialog(null, "the username or passward is incorrect");
		}
	}else
	{
		JOptionPane.showMessageDialog(null, "there is an error");
	}

}

	
	public  void signup(ActionEvent event) throws Exception {
		if(Guestsselect.isSelected()) {
			Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/SignUp.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();

		}else {
			JOptionPane.showMessageDialog(null, "the SignUp just to Guests\n");
		}


	}
	
	
	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

		}
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class signupController implements Initializable {
	@FXML
	private Button backtologin;

	@FXML
	private TextField email;

	@FXML
	private TextField name;

	@FXML
	private TextField pass;

	@FXML
	private TextField phone;

	@FXML
	private Button signup;

	@FXML
	private TextField username;

	public void signup(ActionEvent event) throws Exception {
		try {
			Connection conn = DBConnecter.getConnection();
			// 2. Read the username from the textfield
					String Username= username.getText();

					// 3. Check if the username already exists in the table
					String selectSQL = "SELECT Guests_iD FROM login WHERE Guests_iD = ?";
					PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
					preparedStatement.setString(1, Username);
					ResultSet resultSet = preparedStatement.executeQuery();

					if (resultSet.next()) {
						// The username already exists
						JOptionPane.showMessageDialog(null, "Username already exists");
					} else {
						String sql = "insert into Guests(Guests_iD ,Guests_Name ,Phone_number,Guests_Email)values(?,?,?,?)";
						preparedStatement = conn.prepareStatement(sql);
						preparedStatement.setString(1, username.getText());
						preparedStatement.setString(2, name.getText());
						preparedStatement.setString(3, phone.getText());
						preparedStatement.setString(4, email.getText());

//						String sql2 = "insert into login(Guests_iD ,password)values(?,?)";
//						preparedStatement = conn.prepareStatement(sql2);
//						preparedStatement.setString(1, username.getText());
//						preparedStatement.setString(2, pass.getText());
						JOptionPane.showMessageDialog(null, "Sign-up successful");
					}

					// 4. Close the connection
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}




		public void back (ActionEvent event) throws Exception {
			Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("login.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
		}


		@Override
		public void initialize (URL arg0, ResourceBundle arg1){
			// TODO Auto-generated method stub

		}


}

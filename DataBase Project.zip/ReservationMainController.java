
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javax.security.auth.callback.Callback;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Pattern;

public class ReservationMainController implements Initializable {

	@FXML
	private TextField GuestNameTF;
	@FXML
	private TextField emailTextField;
	@FXML
	private TextField phoneNmuberTextField;
	@FXML
	private DatePicker CheckInDate;
	@FXML
	private DatePicker CheckOutDate;
	@FXML
	private Button insertGuest;

	@FXML
	private Button Paymentpage;
	@FXML
	private Button close;

	private int reservationId;
    public class EmailValidator {
        public static boolean isValid(String email)
        {
            String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                    "[a-zA-Z0-9_+&*-]+)*@" +
                    "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                    "A-Z]{2,7}$";

            Pattern pat = Pattern.compile(emailRegex);
            if (email == null)
                return false;
            return pat.matcher(email).matches();
        }
    }
	@FXML
	private void handleInsertButton(ActionEvent event) throws SQLException, ClassNotFoundException {
		String name = GuestNameTF.getText();
		String email = emailTextField.getText();
		String phone = phoneNmuberTextField.getText();
		if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Error");
			alert.setHeaderText("Empty Field");
			alert.setContentText("Please fill in all the fields");
			alert.showAndWait();
			return;
		} else {
			insertGuest();
			insertRes();
			CheckInDate.setVisible(true);
			CheckOutDate.setVisible(true);
		}
	}

	@FXML
	void closeWindow(ActionEvent event) {
		Stage stage = (Stage) close.getScene().getWindow();
		stage.close();
	}

	@FXML
	private void ReserveButton(ActionEvent event) throws SQLException, ClassNotFoundException, IOException {
		insertRes();

	}

	@FXML
	private void initialize() {
//        CheckInDate.setDayCellFactory(new CustomDateCellFactory());
		CheckInDate.setDayCellFactory(dp -> new DateCell() {
			@Override
			public void updateItem(LocalDate item, boolean empty) {
				super.updateItem(item, empty);

				if (item.isBefore(LocalDate.now())) {
					setDisable(true);
					setStyle("-fx-background-color: #ffc0cb;");
				}
			}
		});

	}

	public void insertGuest() throws SQLException, ClassNotFoundException {

		Connection con = DBConnecter.getConnection();
		// ObservableList<Guests> oblist = FXCollections.observableArrayList();
		String name = GuestNameTF.getText();
		System.out.println("-->" + name);
		String email = emailTextField.getText();
		String phone = phoneNmuberTextField.getText();
		if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
		      Alert alert = new Alert(Alert.AlertType.ERROR);
	            alert.setTitle("Error");
	            alert.setHeaderText("Empty Field");
	            alert.setContentText("Please fill in all the fields");
	            alert.showAndWait();
	            return;
	        }
	        if (!phone.matches("\\d+")) {
	            Alert alert = new Alert(Alert.AlertType.ERROR);
	            alert.setTitle("Error");
	            alert.setHeaderText("Invalid Phone Number");
	            alert.setContentText("Phone number can only contain numbers");
	            alert.showAndWait();
	            return;
	        }
	        if (phone.length() != 10) {
	            Alert alert = new Alert(Alert.AlertType.ERROR);
	            alert.setTitle("Error");
	            alert.setHeaderText("Invalid Phone Number");
	            alert.setContentText("Phone number must be 10 charachters long");
	            alert.showAndWait();
	            return;
	        }
	        if(!EmailValidator.isValid(email)){
	            Alert alert = new Alert(Alert.AlertType.ERROR);
	            alert.setTitle("Error");
	            alert.setHeaderText("Invalid Email");
	            alert.setContentText("Email must be in form of example@example.com");
	            alert.showAndWait();
	            return;
	        }
		String sql = "insert into Guests values (?,?,?,?)";
		PreparedStatement pstmt_guest = con.prepareStatement(sql);
		pstmt_guest.setString(1, getNextGuestId() + "");
		pstmt_guest.setString(2, name);
		pstmt_guest.setString(3, phone);
		pstmt_guest.setString(4, email);
		pstmt_guest.executeUpdate();
	}

	private int getNextGuestId() throws SQLException, ClassNotFoundException {
		Connection con = DBConnecter.getConnection();
		String sql = "SELECT MAX(Guests_iD) FROM Guests";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		if (rs.next()) {
			return rs.getInt(1) + 1;
		}
		return 1;
	}

	private int getNextReservation() throws SQLException, ClassNotFoundException {
		Connection con = DBConnecter.getConnection();
		String sql = "SELECT MAX(ReservationID) FROM Reservation";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		if (rs.next()) {
			return rs.getInt(1) + 1;
		}
		return 1;
	}

	public void insertRes() throws SQLException, ClassNotFoundException {
		try {
			Connection con = DBConnecter.getConnection();
			LocalDate startDate = CheckInDate.getValue();
			LocalDate endDate = CheckOutDate.getValue();

			java.sql.Date SQLsDate = java.sql.Date.valueOf(startDate);
			java.sql.Date SQLeDate = java.sql.Date.valueOf(endDate);
			String dateSQL = "insert into Reservation (ReservationID ,villa_id ,Guests_iD, CheckInDate ,CheckOutDate) values (?,?,?,?,?)";
			PreparedStatement pstmt_date = con.prepareStatement(dateSQL);
			pstmt_date.setString(1, getNextReservation() + "");
			pstmt_date.setInt(2, 1);
			pstmt_date.setInt(3, getGuestID());
			pstmt_date.setDate(4, SQLsDate);
			pstmt_date.setDate(5, SQLeDate);
			pstmt_date.executeUpdate();

		} catch (SQLException e) {
			System.out.println("Error inserting data: " + e.getMessage());
		}
	}

	private int getGuestID() throws SQLException, ClassNotFoundException {
		Connection con = DBConnecter.getConnection();
		String email = emailTextField.getText();
		String sql = "select Guests_iD from Guests where Guests_Email = ?";
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setString(1, email);
		ResultSet rs = statement.executeQuery();
		if (rs.next()) {
			return rs.getInt("Guests_iD");
		}
		return -1;
	}

	@FXML
	void paymentbutton(ActionEvent event) throws Exception {
		Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/PaymentMainScene.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

	@FXML
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		List<LocalDate> reservedDates = loadReservedDates();
		CheckInDate.setDayCellFactory(dp -> new DateCell() {
			@Override
			public void updateItem(LocalDate item, boolean empty) {
				super.updateItem(item, empty);
				if (reservedDates.contains(item) || item.isBefore(LocalDate.now())) {
					setDisable(true);
					setStyle("-fx-background-color: #ffc0cb;");
				}
			}
		});
		CheckOutDate.setDayCellFactory(dp -> new DateCell() {
			@Override
			public void updateItem(LocalDate item, boolean empty) {
				super.updateItem(item, empty);
				if (reservedDates.contains(item) || item.isBefore(CheckInDate.getValue().plusDays(1))) {
					setDisable(true);
					setStyle("-fx-background-color: #ffc0cb;");
				}
			}
		});
	}

	private List<LocalDate> loadReservedDates() {
		List<LocalDate> reservedDates = new ArrayList<>();
		try {
			Connection connection = DBConnecter.getConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT CheckInDate, CheckOutDate FROM Reservation");
			while (resultSet.next()) {
				LocalDate checkin = resultSet.getDate("CheckInDate").toLocalDate();
				LocalDate checkout = resultSet.getDate("CheckOutDate").toLocalDate();
				// Add all dates between checkin and checkout to the list of reserved dates
				for (LocalDate date = checkin; !date.isAfter(checkout); date = date.plusDays(1)) {
					reservedDates.add(date);
				}
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return reservedDates;
	}

	@FXML
	void BacktoMain(ActionEvent event) throws Exception {
		Parent pane = (ScrollPane) FXMLLoader.load(getClass().getResource("/MainMainScene.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
}
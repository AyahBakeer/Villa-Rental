
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.TextArea;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import java.time.LocalDate;

public class paymentmainsceneController {

	@FXML
	private Label ExpirtyDateDash;

	@FXML
	private TextField ExpirtyDateYear;

	@FXML
	private TextField ExpirtyDatemonth;

	@FXML
	private Button SelectCash;

	@FXML
	private Button SelectPreyPay;

	@FXML
	private Label cardnumberlabel;

	@FXML
	private TextField cardnumbertext;

	@FXML
	private Button confirmpaymentbutton;

	@FXML
	private Label expirydatelabel;

	@FXML
	private TextField expirydatetext;

	@FXML
	private AnchorPane mainpane;

	@FXML
	private ImageView paycashimage;

	@FXML
	private Button paymentbackbutton;

	@FXML
	private Text paymentconfirmationtext;

	@FXML
	private ImageView prepayimage;

	@FXML
	private Label securitycodelabel;

	@FXML
	private TextField securitycodetext;

	@FXML
	private Text totaltextarea;

	public String selectcheck = "Not Chosen";

	// private int maxReservationID;

	public int leftdeposit;

	public int totalPrice;

//	public void setReservationId(int reservationId) {
//		this.reservationId = reservationId;
//		System.out.println("Reservation Id in payment controller: " + reservationId);
//	}
//
//	public int getReservationId() {
//		return reservationId;
//	}

	public int getreservationID() throws SQLException, ClassNotFoundException {
		Connection conn = DBConnecter.getConnection();
		String reservationIDQuery = "SELECT MAX(ReservationID) FROM Reservation";
		Statement reservationIDStmt = conn.createStatement();
		ResultSet reservationIDRs = reservationIDStmt.executeQuery(reservationIDQuery);
		int maxReservationID = 0;

		if (reservationIDRs.next()) {
			maxReservationID = reservationIDRs.getInt(1);

			String query = "SELECT Reservation.CheckInDate, Reservation.CheckOutDate, villa_admin.price "
					+ "FROM Guests " + "INNER JOIN Reservation ON Guests.Guests_iD = Reservation.Guests_iD "
					+ "INNER JOIN villa_admin ON Reservation.Villa_ID = villa_admin.Villa_ID "
					+ "WHERE Reservation.ReservationID = " + maxReservationID;

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);

		}

		reservationIDRs.close();
		reservationIDStmt.close();

		return maxReservationID;

	}

	public void totalPriceToPay() throws ClassNotFoundException, SQLException {

		Connection conn = DBConnecter.getConnection();
		String reservationIDQuery = "SELECT MAX(ReservationID) FROM Reservation";
		Statement reservationIDStmt = conn.createStatement();
		ResultSet reservationIDRs = reservationIDStmt.executeQuery(reservationIDQuery);

		if (reservationIDRs.next()) {
			int maxReservationID = reservationIDRs.getInt(1);

			String query = "SELECT Reservation.CheckInDate, Reservation.CheckOutDate, villa_admin.price "
					+ "FROM Guests " + "INNER JOIN Reservation ON Guests.Guests_iD = Reservation.Guests_iD "
					+ "INNER JOIN villa_admin ON Reservation.Villa_ID = villa_admin.Villa_ID "
					+ "WHERE Reservation.ReservationID = " + maxReservationID;

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);

			System.out.println(stmt);
			System.out.println(rs);
			if (rs.next()) {
				LocalDate startDate = rs.getDate("CheckInDate").toLocalDate();
				LocalDate endDate = rs.getDate("CheckOutDate").toLocalDate();
				long totalDays = ChronoUnit.DAYS.between(startDate, endDate);
				String pricePerNight = rs.getString("price");
				int pricePerNightInt = 0;
				try {
					pricePerNightInt = Integer.parseInt(pricePerNight);
				} catch (NumberFormatException e) {
					System.out.println("The price per night is not a valid integer: " + pricePerNight);

				}
				totalPrice = (int) (pricePerNightInt * totalDays);
				totaltextarea.setText("₪" + totalPrice);
//	        setText("The total price to be paid is: $" + totalPrice);
				// totaltextarea.setText("A");

			}

			System.out.println(maxReservationID);

			reservationIDRs.close();
			reservationIDStmt.close();
			// totaltextarea.setText("A");
			rs.close();
			stmt.close();
			conn.close();
		}
	}

	@FXML
	public void selectprepayaction(ActionEvent event) {

		cardnumberlabel.setVisible(true);
		securitycodelabel.setVisible(true);
		expirydatelabel.setVisible(true);
		cardnumbertext.setVisible(true);
		securitycodetext.setVisible(true);
		ExpirtyDateDash.setVisible(true);
		ExpirtyDateYear.setVisible(true);
		ExpirtyDatemonth.setVisible(true);

		selectcheck = "PrePaied";
		leftdeposit = 0;
	}

	@FXML
	public void confirmpaymentbutton(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
		Connection con = DBConnecter.getConnection();

		String cardNumberTextString = cardnumbertext.getText();
		String securityCodeTextString = securitycodetext.getText();
		// String expiryDateTextString = expirydatetext.getText();
		String expiryMonth = ExpirtyDateYear.getText();
		String expiryYear = ExpirtyDatemonth.getText();

		if (selectcheck == "Cash") {
			String sql = "insert into payment  (payment_ID,ReservationID,amount,method,date,deposit) values (?,?,?,?,?,?)";
			PreparedStatement pstmt_payment = con.prepareStatement(sql);
			pstmt_payment.setInt(1, getNextPaymenttId());
			pstmt_payment.setInt(2, getreservationID());
			pstmt_payment.setInt(3, totalPrice);
			pstmt_payment.setString(4, selectcheck);
//		    pstmt_guest.setDate(5, (java.time.LocalDate.now()));
			LocalDate localDate = java.time.LocalDate.now();
			java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
			pstmt_payment.setDate(5, sqlDate);
			pstmt_payment.setLong(6, leftdeposit);
			pstmt_payment.execute();
			Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/PaymentSuccessfull.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
		} else if (selectcheck == "PrePaied" && cardNumberTextString.isEmpty() && securityCodeTextString.isEmpty()
				&& expiryMonth.isEmpty() && expiryYear.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Error! Fileds are empty.");
		} else if (selectcheck == "PrePaied" && cardNumberTextString.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Error! Card number field is empty.");
		} else if (selectcheck == "PrePaied" && securityCodeTextString.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Error! Security code is empty.");
		} else if (selectcheck == "Not Chosen") {
			JOptionPane.showMessageDialog(null, "Please select a payment method.");
		} else if (selectcheck == "PrePaied" && expiryMonth.isEmpty() || expiryYear.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Error! Expiry date is empty.");
		} else if (selectcheck == "PrePaied" && expiryMonth.length() != 2 || Integer.parseInt(expiryMonth) < 0
				|| expiryYear.length() != 2 || Integer.parseInt(expiryYear) < 0) {
			JOptionPane.showMessageDialog(null, "Error! Write the date in the form MM/YY.");
		} else if (selectcheck == "PrePaied" && Integer.parseInt(expiryMonth) > 12 || Integer.parseInt(expiryMonth) < 1
				|| Integer.parseInt(expiryYear) < 0) {
			JOptionPane.showMessageDialog(null, "Error! Check the expiry date.");
		} else {
			String sql = "insert into payment  (payment_ID,ReservationID,amount,method,date,deposit) values  (?,?,?,?,?,?)";
			PreparedStatement pstmt_payment = con.prepareStatement(sql);
			pstmt_payment.setInt(1, getNextPaymenttId());
			pstmt_payment.setInt(2, getreservationID());
			pstmt_payment.setInt(3, totalPrice);
			pstmt_payment.setString(4, selectcheck);
//		        pstmt_guest.setDate(5, (java.time.LocalDate.now()));
			LocalDate localDate = java.time.LocalDate.now();
			java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
			pstmt_payment.setDate(5, sqlDate);
			pstmt_payment.setLong(6, leftdeposit);
			pstmt_payment.execute();

			// int GuestInserted = pstmt_payment.executeUpdate();
			Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/PaymentSuccessfull.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
		}
	}

	private int getNextPaymenttId() throws SQLException, ClassNotFoundException {
		Connection con = DBConnecter.getConnection();
		String sql = "SELECT MAX(payment_ID) FROM Payment";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		if (rs.next()) {
			return rs.getInt(1) + 1;
		}
		return 1;
	}

	@FXML
	public void selectcashaction(ActionEvent event) {

		cardnumberlabel.setVisible(false);
		securitycodelabel.setVisible(false);
		expirydatelabel.setVisible(false);
		cardnumbertext.setVisible(false);
		securitycodetext.setVisible(false);
		ExpirtyDateDash.setVisible(false);
		ExpirtyDateYear.setVisible(false);
		ExpirtyDatemonth.setVisible(false);
		selectcheck = "Cash";
		leftdeposit = totalPrice;
	}

	@FXML
	private void initialize() throws ClassNotFoundException, SQLException {
//		setReservationId(reservationID);
//		System.out.println(reservationId);
		totalPriceToPay();
		totaltextarea = (Text) mainpane.lookup("#totaltextarea");

	}

	@FXML
	void BacktoMain(ActionEvent event) throws Exception {
		Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/ReservationMainScene.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
}

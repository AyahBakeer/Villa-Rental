import java.sql.*;
import java.util.Properties;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DBConnecter {


    public static Connection getConnection() throws SQLException, ClassNotFoundException {
    	 String dbURL;
         String dbUsername = "root";
         String dbPassword = "Anayah:P";
         String URL = "localhost";
         String port = "3306";
         String dbName = "pro";
         Connection con;

        dbURL = "jdbc:mysql://" + URL + ":" + port + "/" + dbName + "?verifyServerCertificate=false";
        Properties p = new Properties();
        p.setProperty("user", dbUsername);
        p.setProperty("password", dbPassword);
        p.setProperty("useSSL", "false");
        p.setProperty("autoReconnect", "true");
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection (dbURL, p);
        return con;
    }



    public static ObservableList<Guests> getDataGuests() {
        System.out.println("here test");
        Connection con;
        ObservableList<Guests> oblist = FXCollections.observableArrayList();
        try {
            con= DBConnecter.getConnection();
            ResultSet resultSet = con.createStatement().executeQuery("select * from guests");
            System.out.println(resultSet.toString());
            while(resultSet.next()){
                oblist.add(new Guests (
                        resultSet.getString(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getString(4)

                        ));
            }


        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return oblist;
    }


    public static ObservableList<Villa_admin> getDataVilla_admin(){
        Connection con;
        ObservableList<Villa_admin> oblist = FXCollections.observableArrayList();
        try {
            con = DBConnecter.getConnection();
            ResultSet resultSet = con.createStatement().executeQuery("select * from Villa_admin");
            while(resultSet.next()){
                oblist.add(new Villa_admin(
                        Integer.parseInt(resultSet.getString(1)),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getString(4),
                        Integer.parseInt(resultSet.getString(5)),
                        Integer.parseInt(resultSet.getString(6)),
                        Integer.parseInt(resultSet.getString(7)),
                        Double.parseDouble(resultSet.getString(8))
                ));
            }


        } catch (SQLException | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return oblist;
    }



    public static ObservableList<Owner_Villa> getDataOwner_Villa(){
        Connection con;
        ObservableList<Owner_Villa> oblist = FXCollections.observableArrayList();
        try {
            con = DBConnecter.getConnection();
            ResultSet resultSet = con.createStatement().executeQuery("select * from Owner_Villa");
            while(resultSet.next()){
                oblist.add(new Owner_Villa(
                        Integer.parseInt(resultSet.getString(1)),
                        Integer.parseInt(resultSet.getString(2)),
                        resultSet.getString(3),
                        Integer.parseInt(resultSet.getString(4)),
                        resultSet.getString(5)
                ));
            }


        } catch (SQLException | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return oblist;
    }


    public static ObservableList<Payment> Payment() throws ClassNotFoundException {
        Connection con;
        ObservableList<Payment> oblist = FXCollections.observableArrayList();
        try {
            con= DBConnecter.getConnection();
            ResultSet resultSet = con.createStatement().executeQuery("select * from Payment");
            while(resultSet.next()){
                oblist.add(new Payment (
                		
                        Integer.parseInt(resultSet.getString(1)),
                        Integer.parseInt(resultSet.getString(2)),
                        Integer.parseInt(resultSet.getString(3)),
                        resultSet.getString(4),
                        resultSet.getDate(5),
                        resultSet.getFloat(6)
                     //   Integer.parseInt(resultSet.getString(7))

                ));
            }


        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return oblist;
    }
}
import javafx.scene.control.TableView;

public class Guests extends TableView<Guests>{

    private String Guests_iD;
    private String Guests_Name;
    private String Phone_number;
    private String Guests_Email;


    public Guests(String Guests_iD,String Guests_Name,String Phone_number,String Guests_Email) {
        this.Guests_iD= Guests_iD;
        this.Guests_Name=Guests_Name;
        this.Phone_number=Phone_number;
        this.Guests_Email=Guests_Email;
    }


    public String getGuests_iD() {
        return Guests_iD;
    }

    public void setGuests_iD(String guests_iD) {
        Guests_iD = guests_iD;
    }

    public String getGuests_Name() {
        return Guests_Name;
    }

    public void setGuests_Name(String guests_Name) {
        Guests_Name = guests_Name;
    }

    public String getPhone_number() {
        return Phone_number;
    }

    public void setPhone_number(String phone_number) {
        Phone_number = phone_number;
    }

    public String getGuests_Email() {
        return Guests_Email;
    }

    public void setGuests_Email(String guests_Email) {
        Guests_Email = guests_Email;
    }


}

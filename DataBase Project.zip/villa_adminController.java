import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class villa_adminController implements Initializable {

    @FXML
    private TableColumn<Villa_admin, Integer> ID;
    @FXML
    private TableColumn<Villa_admin,String> Location;
    @FXML
    private TableColumn<Villa_admin,Integer> max_number_of_people;
    @FXML
    private TableColumn<Villa_admin,Integer> number_of_bathroom;
    @FXML
    private TableView<Villa_admin> Villa_admin;
    @FXML
    private TableColumn<Villa_admin,Integer> number_of_bed;

    @FXML
    private TableColumn<Villa_admin,Double> Price;

    @FXML
    private TableColumn<Villa_admin,String> Description;
    @FXML
    private TableColumn<Villa_admin,String> villa_name;


    @FXML
    private Button ADD;

    @FXML
    private Button Delete;

    @FXML
    private TextField NumberOfBathroom;

    @FXML
    private TextField NumberOfBed;

    @FXML
    private Text T;

    @FXML
    private Button Update;

    @FXML
    private TextField description;

    @FXML
    private TextField location;

    @FXML
    private TextField maxNumberOfPeople;


    @FXML
    private TextField price;

    @FXML
    private TextField search;

    @FXML
    private TextField villa_id;

    @FXML
    private TextField villa_Name;


    ObservableList<Villa_admin> list = FXCollections.observableArrayList();

    PreparedStatement stat=null;
    ResultSet RS=null;
    int in=-1;


    @FXML
    void Add(ActionEvent event) throws SQLException, ClassNotFoundException {
        Connection con = DBConnecter.getConnection();
        String sql = "insert into villa_admin( villa_id,villa_name ,location,description,max_number_of_people,number_of_bed,number_of_bathroom,price)values(?,?,?,?,?,?,?,?)";
        try{
            stat = con.prepareStatement(sql);
            stat.setString(1,villa_id.getText());
            stat.setString(2,villa_name.getText());
            stat.setString(3,location.getText());
            stat.setString(4,description.getText());
            stat.setString(5,maxNumberOfPeople.getText());
            stat.setString(6,NumberOfBed.getText());
            stat.setString(7,NumberOfBathroom.getText());
            stat.setString(8,price.getText());
            stat.execute();
            JOptionPane.showMessageDialog(null, "villa Add Success");
            updatable();
        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);

        }

    }

    @FXML
    void Delete(ActionEvent event) throws SQLException, ClassNotFoundException {
        Connection con = DBConnecter.getConnection();
        String sql = "delete from villa_admin where villa_id=?";
        try{
            stat = con.prepareStatement(sql);
            stat.setString(1,villa_id.getText());
            stat.execute();
            JOptionPane.showMessageDialog(null, "Delete");
            updatable();
        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    @FXML
    void Update(ActionEvent event)throws SQLException, ClassNotFoundException {
        Connection con = DBConnecter.getConnection();
        try {
            int id =Integer.parseInt(villa_id.getText());
            String name = villa_name.getText();
            String Location =location .getText();
            String Description = description.getText();
            int maxp =Integer.parseInt(maxNumberOfPeople.getText());
            int numofbed =Integer.parseInt(NumberOfBed.getText());
            int numofbathroom =Integer.parseInt(NumberOfBathroom.getText());
            double Price =Double.parseDouble(price.getText());


            String sql="update villa_admin set villa_name='"+name+"',location='"+Location+"',description='"+Description+"',max_number_of_people='"+maxp+"',number_of_bed='"+numofbed+"',number_of_bathroom='"+numofbathroom+"',price='"+Price+"'Where villa_id='"+id+"'";
            stat=con.prepareStatement(sql);
            stat.execute();
            JOptionPane.showMessageDialog(null, "Update");
            updatable();
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    @FXML
    void select(MouseEvent event) {
        in = Villa_admin.getSelectionModel().getSelectedIndex();
        if(in <=-1)
        {
            return;
        }
        villa_id.setText(ID.getCellData(in).toString());
        villa_Name.setText(villa_name.getCellData(in).toString());
        location.setText(Location.getCellData(in).toString());
        description.setText(Description.getCellData(in).toString());
        maxNumberOfPeople.setText(max_number_of_people.getCellData(in).toString());
        NumberOfBed.setText(number_of_bed.getCellData(in).toString());
        NumberOfBathroom.setText(number_of_bathroom.getCellData(in).toString());
        price.setText(Price.getCellData(in).toString());

    }


    public void updatable()
    {
        ID.setCellValueFactory(new PropertyValueFactory<Villa_admin,Integer>("villa_id"));
        villa_name.setCellValueFactory(new PropertyValueFactory<Villa_admin,String>("villa_name"));
        Location.setCellValueFactory(new PropertyValueFactory<Villa_admin,String>("Location"));
        Description.setCellValueFactory(new PropertyValueFactory<Villa_admin,String>("Description"));
        max_number_of_people.setCellValueFactory(new PropertyValueFactory<Villa_admin,Integer>("max_number_of_people"));
        number_of_bed.setCellValueFactory(new PropertyValueFactory<Villa_admin,Integer>("number_of_bed"));
        number_of_bathroom.setCellValueFactory(new PropertyValueFactory<Villa_admin,Integer>("number_of_bathroom"));
        Price.setCellValueFactory(new PropertyValueFactory<Villa_admin,Double>("Price"));
        list = DBConnecter.getDataVilla_admin();
        Villa_admin.setItems(list);
    }

    public void close(ActionEvent actionEvent) throws  Exception{
        Parent pane = (ScrollPane) FXMLLoader.load(getClass().getResource("/MainMainScene.fxml"));
        Scene scene = new Scene(pane);
        Stage window = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    public void count(javafx.event.ActionEvent actionEvent) {
        try {
            int num = 0;
            Connection con = DBConnecter.getConnection();
            String sql="Select Count(*) from Villa_admin";
            stat =con.prepareStatement(sql);
            ResultSet r = stat.executeQuery();
            if (r.next()) {
                num = r.getInt(1);
            }
            JFrame f=new JFrame();
            JOptionPane.showMessageDialog(f,"The number of Villa: " +num,"Number of Villa",JOptionPane.PLAIN_MESSAGE);
            con.close();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void max_price(ActionEvent actionEvent) {
        try {
            int num = 0;
            Connection con = DBConnecter.getConnection();
            String sql="Select MAX(price) from Villa_admin V";
            stat =con.prepareStatement(sql);
            ResultSet r = stat.executeQuery();
            if (r.next()) {
                num = r.getInt(1);
            }
            JFrame f=new JFrame();
            JOptionPane.showMessageDialog(f,"The max price:" +num,"maximum price",JOptionPane.PLAIN_MESSAGE);
            con.close();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }



    public void search(TableView<Villa_admin> Villa_admin, TextField search, ObservableList<Villa_admin> list){

        // All data from Villa_admin table is shown initially
        FilteredList<Villa_admin> filterList = new FilteredList<>(list, b -> true);

        // Every time a search text field changes, the filter should be set to predict it
        search.textProperty().addListener((observable, newValue, oldValue) -> {
            filterList.setPredicate(villaadmin -> {

                // if the search is empty, show all data from Villa_admin table
                if (newValue.isEmpty() || newValue.isBlank() || newValue == null) {
                    return true;
                }
                String searchKeyword = newValue.toLowerCase();

                if ((String.valueOf(villaadmin.getVilla_id())).indexOf(searchKeyword) > -1) {

                    return true; // When found match in Villa_admin id

                } else if (villaadmin.getVilla_name().toLowerCase().indexOf(searchKeyword) > -1) {

                    return true; // When found match in Villa_admin name

                } else if (villaadmin.getDescription().toLowerCase().indexOf(searchKeyword) > -1) {

                    return true; // When found match in Villa_admin description

                } else if (villaadmin.getLocation().toLowerCase().indexOf(searchKeyword) > -1) {

                    return true; // When found match in Villa_admin location

                }else if ((String.valueOf(villaadmin.getPrice())).indexOf(searchKeyword) > -1) {

                    return true; // When found match in price

                } else if ((String.valueOf(villaadmin.getNumber_of_bathroom())).indexOf(searchKeyword) > -1) {

                    return true; // When found match in Number_of_bathroom

                } else if ((String.valueOf(villaadmin.getNumber_of_bed())).indexOf(searchKeyword) > -1) {

                    return true; // When found match in Number_of_bed

                } else if ((String.valueOf(villaadmin.getMax_number_of_people())).indexOf(searchKeyword) > -1) {

                    return true; // When found match in Max_number_of_people

                } else
                    return false;// When no match found
            });
        });
        SortedList<Villa_admin> sortedData = new SortedList<>(filterList);

        // The sorted result should be bound to the "Villa_admin" table view
        sortedData.comparatorProperty().bind(Villa_admin.comparatorProperty());

        Villa_admin.setItems(sortedData);
    }


    public void maxnumofpeople(ActionEvent actionEvent) {
        try {
            int num = 0;
            Connection con = DBConnecter.getConnection();
            String sql="SELECT S.villa_id FROM Villa_admin S WHERE S.max_number_of_people =(SELECT MAX(S.max_number_of_people) FROM Villa_admin S);";
            stat =con.prepareStatement(sql);
            ResultSet r = stat.executeQuery();
            if (r.next()) {
                num = r.getInt(1);
            }
            JFrame f=new JFrame();
            JOptionPane.showMessageDialog(f,"villa id for max_number_of_people:" +num,"",JOptionPane.PLAIN_MESSAGE);
            con.close();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void maxnumofbed(ActionEvent actionEvent) {
        try {
            int num = 0;
            Connection con = DBConnecter.getConnection();
            String sql="SELECT S.villa_id FROM Villa_admin S WHERE S.number_of_bed =(SELECT MAX(S.number_of_bed) FROM Villa_admin S);";
            stat =con.prepareStatement(sql);
            ResultSet r = stat.executeQuery();
            if (r.next()) {
                num = r.getInt(1);
            }
            JFrame f=new JFrame();
            JOptionPane.showMessageDialog(f,"villa id for max_num_of_bed:" +num,"",JOptionPane.PLAIN_MESSAGE);
            con.close();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void max_number_of_bathroom(ActionEvent actionEvent) {
        try {
            int num = 0;
            Connection con = DBConnecter.getConnection();
            String sql="SELECT S.villa_id FROM Villa_admin S WHERE S.number_of_bathroom =(SELECT MAX(S.number_of_bathroom) FROM Villa_admin S);";
            stat =con.prepareStatement(sql);
            ResultSet r = stat.executeQuery();
            if (r.next()) {
                num = r.getInt(1);
            }
            JFrame f=new JFrame();
            JOptionPane.showMessageDialog(f,"villa id for max_number_of_bathroom:" +num,"",JOptionPane.PLAIN_MESSAGE);
            con.close();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(java.net.URL arg0, ResourceBundle arg1) {

        updatable();
        search(Villa_admin, search, list);

    }

}

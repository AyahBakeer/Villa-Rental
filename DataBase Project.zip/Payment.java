

import java.util.Date;

import javafx.scene.control.TableView;

public class Payment{
	int payment_ID;
	int reservation_ID;
	int amount;
	String method;
	Date date;
	float deposit;

	public Payment(int payment_ID, int reservation_ID, int amount, String method, Date date, float deposit ) {
		super();
		this.payment_ID = payment_ID;
		this.reservation_ID = reservation_ID;
		this.amount = amount;
		this.method = method;
		this.date = date;
		this.deposit = deposit;
	}

	
	public Payment() {
		super();
	}


	public int getPayment_ID() {
		return payment_ID;
	}

	public void setPayment_ID(int payment_ID) {
		this.payment_ID = payment_ID;
	}

	public int getReservation_ID() {
		return reservation_ID;
	}

	public void setReservation_ID(int reservation_ID) {
		this.reservation_ID = reservation_ID;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public float getDeposit() {
		return deposit;
	}

	public void setDeposit(float deposit) {
		this.deposit = deposit;
	}

}
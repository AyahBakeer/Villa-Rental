import javafx.fxml.Initializable;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import org.w3c.dom.Text;

import javax.swing.*;
import javafx.scene.control.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.Properties;
import java.util.ResourceBundle;

public class Owner_Villa_interface implements Initializable {

    @FXML
    private TableColumn<Owner_Villa,Integer> Owner_ID;

    @FXML
    private TableColumn<Owner_Villa,Integer> Villa_ID;

    @FXML
    private TableColumn<Owner_Villa,Integer> owner_Phone_number;


    @FXML
    private TableColumn<Owner_Villa,String> owner_email;


    @FXML
    private TableColumn<Owner_Villa,String> owner_name;

    @FXML
    private TableView<Owner_Villa> Owner_Villa;

    @FXML
    private Button Add;

    @FXML
    private Button Delete;

    @FXML
    private Text T;

    @FXML
    private Button Update;

    @FXML
    private Button close;

    @FXML
    private AnchorPane owner;
    @FXML
    private TextField txt_phone_number;

    @FXML
    private TextField txt_email;

    @FXML
    private TextField txt_oid;

    @FXML
    private TextField txt_name;
    @FXML
    private Pane pane;

    @FXML
    private TextField txt_vid;

   @FXML
    void Add_Owner(ActionEvent event) {

    }

    @FXML
    void select(MouseEvent event) {

    }

    @FXML
    void Update_Owner(ActionEvent event) {

    }
    @FXML
    void Delete_Owner(ActionEvent event) {

    }


    ObservableList<Owner_Villa> list = FXCollections.observableArrayList();

    PreparedStatement stat=null;
    ResultSet RS=null;
    int in=-1;


    public void updatable()
    {
        Owner_ID.setCellValueFactory(new PropertyValueFactory<Owner_Villa,Integer>("Owner_ID"));
        Villa_ID.setCellValueFactory(new PropertyValueFactory<Owner_Villa,Integer>("Villa_ID"));
        owner_name.setCellValueFactory(new PropertyValueFactory<Owner_Villa,String>("owner_name"));
        owner_Phone_number.setCellValueFactory(new PropertyValueFactory<Owner_Villa,Integer>("owner_Phone_number"));
        owner_email.setCellValueFactory(new PropertyValueFactory<Owner_Villa,String>("owner_email"));
        list = DBConnecter.getDataOwner_Villa();
        Owner_Villa.setItems(list);


    }

    @Override
    public void initialize(java.net.URL arg0, ResourceBundle arg1) {

        updatable();
    }

    public void select()
    {
        in=Owner_Villa.getSelectionModel().getSelectedIndex();
        if(in <=-1)
        {
            return;
        }
        txt_oid.setText(Owner_ID.getCellData(in).toString());
        txt_vid.setText(Villa_ID.getCellData(in).toString());
        txt_name.setText(owner_name.getCellData(in).toString());
        txt_phone_number.setText(owner_Phone_number.getCellData(in).toString());
        txt_email.setText(owner_email.getCellData(in).toString());


    }

    public void  Add_Owner() throws SQLException, ClassNotFoundException {

//       Owner_Villa O=new Owner_Villa(Integer.parseInt(Owner_ID.getText()),Integer.parseInt(Villa_ID.getText()),owner_name.getText(),Integer.parseInt(owner_Phone_number.getText()),owner_email.getText());
        Connection con = DBConnecter.getConnection();
        Statement statement = con.createStatement();
        String sql = "insert into Owner_Villa(Owner_ID,Villa_ID,owner_name,owner_Phone_number,owner_email)values(?,?,?,?,?)";
        try{
            stat = con.prepareStatement(sql);
            stat.setString(1,txt_oid.getText());
            stat.setString(2,txt_vid.getText());
            stat.setString(3,txt_name.getText());
            stat.setString(4,txt_phone_number.getText());
            stat.setString(5,txt_email.getText());
            stat.execute();
            JOptionPane.showMessageDialog(null, "Owner Add Success");
            updatable();
        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public void Update_Owner() throws SQLException, ClassNotFoundException {
        Connection con = DBConnecter.getConnection();
        Statement statement = con.createStatement();
        try {
            String Oid = txt_oid.getText();
            String Vid = txt_vid.getText();
            String name = txt_name.getText();
            String phone = txt_phone_number.getText();
            String email = txt_email.getText();
            String sql="update Owner_Villa set Villa_ID='"+Vid+"',"+
                    "owner_name='"+name+"',owner_Phone_number='"+phone+"',owner_email='"+email+"'Where Owner_ID='"+Oid+"'";
            stat=con.prepareStatement(sql);
            stat.execute();
            JOptionPane.showMessageDialog(null, "Update");
            updatable();
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void Delete_Owner() throws SQLException, ClassNotFoundException {
        Connection con = DBConnecter.getConnection();
        Statement statement = con.createStatement();
        String sql = "delete from Owner_Villa where Owner_ID=?";
        try{
            stat = con.prepareStatement(sql);
            stat.setString(1,txt_oid.getText());
            stat.execute();
            JOptionPane.showMessageDialog(null, "Delete");
            updatable();
        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);

        }

    }
    @FXML
    void Backbtn(ActionEvent event) throws Exception {
    	Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/details.fxml"));
    	Scene scene = new Scene(pane);
    	Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	window.setScene(scene);
    	window.show();
    }



}

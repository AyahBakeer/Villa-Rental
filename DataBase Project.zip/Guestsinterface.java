import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import org.w3c.dom.Text;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.ResourceBundle;


public class Guestsinterface implements Initializable {
    @FXML
    private Button ADD;

    @FXML
    private Button close;
    @FXML
    private Button Delete;

    @FXML
    private Button Close;

    @FXML
    private Button Update;

    @FXML
    private AnchorPane G;

    @FXML
    private Text t;

    @FXML
    private TableView<Guests> Guests;

    @FXML
    private TableColumn<Guests,String> Guests_Email;

    @FXML
    private TableColumn<Guests,String> Guests_Name;

    @FXML
    private TableColumn<Guests,String> Guests_iD;

    @FXML
    private TableColumn<Guests,String> Phone_number;

    @FXML
    private Pane pane;

    @FXML
    private TextField txt_Email;

    @FXML
    private TextField txt_id;

    @FXML
    private TextField txt_name;

    @FXML
    private TextField txt_phone_number;


    @FXML
    void AddGuests(ActionEvent event) {

    }

    @FXML
    void Delete(ActionEvent event) {

    }

    @FXML
    void Update(ActionEvent event) {

    }
    @FXML
    void select(MouseEvent event)
    {

    }

    ObservableList<Guests> list = FXCollections.observableArrayList();


    PreparedStatement stat=null;
    ResultSet RS=null;
    int in=-1;


    public void select() throws SQLException, ClassNotFoundException {
        in=Guests.getSelectionModel().getSelectedIndex();
        if(in <=-1)
        {
            return;
        }
        txt_id.setText(Guests_iD.getCellData(in).toString());
        txt_name.setText(Guests_Name.getCellData(in).toString());
        txt_phone_number.setText(Phone_number.getCellData(in).toString());
        txt_Email.setText(Guests_Email.getCellData(in).toString());
    }

    public void  AddGuests() throws SQLException, ClassNotFoundException {

        Connection con = DBConnecter.getConnection();
            String sql = "insert into Guests(Guests_iD ,Guests_Name ,Phone_number,Guests_Email)values(?,?,?,?)";
            try{
            stat = con.prepareStatement(sql);
            stat.setString(1,txt_id.getText());
            stat.setString(2,txt_name.getText());
            stat.setString(3,txt_phone_number.getText());
            stat.setString(4,txt_Email.getText());
            stat.execute();
           JOptionPane.showMessageDialog(null, "Guest Add Success");
           updatable();
        } catch (Exception e)
        {
          JOptionPane.showMessageDialog(null, e);

        }
    }

    public void Update() throws SQLException, ClassNotFoundException {
        Connection con = DBConnecter.getConnection();
        try {
            int id = Integer.parseInt(txt_id.getText());
            String name = txt_name.getText();
            String phone = txt_phone_number.getText();
            String email = txt_Email.getText();
            String sql="update Guests set Guests_Name='"+name+"'," +
                    "Phone_number='"+phone+"',Guests_Email='"+email+"'Where Guests_iD='"+id+"'";
            stat=con.prepareStatement(sql);
            stat.execute();
            JOptionPane.showMessageDialog(null, "Update");
            updatable();
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void updatable()
    {
        Guests_iD.setCellValueFactory(new PropertyValueFactory<Guests,String>("Guests_iD"));
        Guests_Name.setCellValueFactory(new PropertyValueFactory<Guests,String>("Guests_Name"));
        Phone_number.setCellValueFactory(new PropertyValueFactory<Guests,String>("Phone_number"));
        Guests_Email.setCellValueFactory(new PropertyValueFactory<Guests,String>("Guests_Email"));
        list = DBConnecter.getDataGuests();
        Guests.setItems(list);
    }

    public void Delete() throws SQLException, ClassNotFoundException {
        Connection con = DBConnecter.getConnection();
        String sql = "delete from Guests where Guests_iD=?";
        try{
            stat = con.prepareStatement(sql);
            stat.setString(1,txt_id.getText());
            stat.execute();
            JOptionPane.showMessageDialog(null, "Delete");
            updatable();
        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);

        }

    }

    public void close(javafx.event.ActionEvent actionEvent) throws Exception{
        Parent pane = (ScrollPane) FXMLLoader.load(getClass().getResource("/MainMainScene.fxml"));
        Scene scene = new Scene(pane);
        Stage window = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    public void count(javafx.event.ActionEvent actionEvent) {
        try {
            int num = 0;
            Connection con = DBConnecter.getConnection();
            String sql="Select Count(*) from Guests";
            stat =con.prepareStatement(sql);
            ResultSet r = stat.executeQuery();
            if (r.next()) {
                num = r.getInt(1);
            }
            JFrame f=new JFrame();
            JOptionPane.showMessageDialog(f,"The number of Guests: " +num,"Number of Guests",JOptionPane.PLAIN_MESSAGE);
            con.close();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }



    @Override
    public void initialize(java.net.URL arg0, ResourceBundle arg1) {

        updatable();
    }
}


import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Reservation {

    private int res_id;
    private int villa_id;
    private int guest_id;
    private Date startDate;
    private Date endDate;

    public Reservation(int res_id, int villa_id, int guest_id, Date startDate, Date endDate) {
        this.res_id = res_id;
        this.villa_id = villa_id;
        this.guest_id = guest_id;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Connection getConnection() throws SQLException {
        Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/reserv","root","root1234");
        return connection;
    }

    public static Reservation getReservation(int id, Connection connection) throws SQLException {
        String sql = "SELECT * FROM reservation WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet result = statement.executeQuery();
        if (result.next()) {
            int res_id = result.getInt("ReservationID");
            int guest = result.getInt("guest_id");
            Date startDate = result.getDate("CheckInDate");
            Date endDate = result.getDate("CheckOutDate");
            int villa = result.getInt("villa_id");
            return new Reservation(res_id, villa, guest, startDate, endDate);
        }
        return null;
    }

//    public List<Reservation> getAllReservations() throws SQLException {
//        List<Reservation> reservations = new ArrayList<>();
//        try (Connection connection = getConnection();
//             PreparedStatement statement = connection.prepareStatement("SELECT * FROM Reservation INNER JOIN Guest ON Reservation.guest_id = Guest.guest_id INNER JOIN villas ON Reservation.villa_id = villas.villa_id");
//             ResultSet resultSet = statement.executeQuery()) {
//            while (resultSet.next()) {
//                Reservation reservation = new Reservation();
//                reservation.setRes_id(resultSet.getInt("ReservationID"));
//                reservation.setVilla_id(resultSet.getInt("villa_id"));
//                reservation.setGuest_id(resultSet.getInt("guest_id"));
//                reservation.setStartDate(resultSet.getDate("CheckInDate"));
//                reservation.setEndDate(resultSet.getDate("CheckOutDate"));
//                reservation.setVillaName(resultSet.getString("v_name"));
//                reservation.setGuestFirstName(resultSet.getString("fname"));
//                reservation.setGuestLastName(resultSet.getString("lname"));
//                reservation.setGuestEmail(resultSet.getString("email"));
//                reservation.setGuestPhoneNumber(resultSet.getLong("phone_number"));
//                reservations.add(reservation);
//            }
//        }
//        return reservations;
//    }

    public void cancelReservation(int reservationID) {
        try (Connection con = getConnection()) {
            String sql = "DELETE FROM reservation WHERE reservation_id = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setInt(1, reservationID);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean checkAvailability(int villaId, Date checkInDate, Date checkOutDate) throws SQLException {

            Connection con = getConnection();
            String sql = "SELECT * FROM Reservation WHERE villa_id = ? AND CheckInDate <= ? AND CheckOutDate >= ?";
            PreparedStatement statement = con.prepareStatement(sql);

            statement.setInt(1, villaId);
            statement.setDate(2, (java.sql.Date) startDate);
            statement.setDate(3, (java.sql.Date) endDate);
            ResultSet resultSet = statement.executeQuery();

            if (!resultSet.next()) {
                return true;
            }

        return false;
    }


    public void update(int reservationId, String startDate, String endDate) {
        try {
            Connection con = getConnection();
            String updateSql = "UPDATE reservation SET start_date = ?, end_date = ? WHERE reservation_id = ?";
            PreparedStatement updateStmt = con.prepareStatement(updateSql);
            updateStmt.setString(1, startDate);
            updateStmt.setString(2, endDate);
            updateStmt.setInt(3, reservationId);
            updateStmt.executeUpdate();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getRes_id() {
        return res_id;
    }

    public void setRes_id(int res_id) {
        this.res_id = res_id;
    }

    public int getVilla_id() {
        return villa_id;
    }

    public void setVilla_id(int villa_id) {
        this.villa_id = villa_id;
    }

    public int getGuest_id() {
        return guest_id;
    }

    public void setGuest_id(int guest_id) {
        this.guest_id = guest_id;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
}

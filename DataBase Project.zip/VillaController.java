

import java.io.IOException;

import javafx.event.ActionEvent;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class VillaController {
	

	@FXML
	 void viewvilla1photos(ActionEvent event) throws Exception {
		Parent pane = (ScrollPane) FXMLLoader.load(getClass().getResource("/VillaPhotos.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
	@FXML
	 void BacktoMain(ActionEvent event) throws Exception {
		Parent pane = (ScrollPane) FXMLLoader.load(getClass().getResource("/MainMainScene.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
	 @FXML
	  void ReserveBtb(ActionEvent event) throws IOException {
		  Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/ReservationMainScene.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
	    }

}



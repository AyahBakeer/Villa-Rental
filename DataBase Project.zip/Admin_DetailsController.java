import javafx.fxml.FXML;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javax.swing.text.html.ImageView;
import javafx.event.ActionEvent;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.control.ScrollPane;

public class Admin_DetailsController implements Initializable {


    @FXML
    private Button GUESTSDETAILS;

    @FXML
    private Button OWNERDETAILS;

    @FXML
    private AnchorPane T;

    @FXML
    private ImageView Tt;

    @FXML
    private Button VillaDETAILS;

    @FXML
    void guests(ActionEvent event) throws Exception{
        Parent pane = (ScrollPane) FXMLLoader.load(getClass().getResource("/aya.fxml"));
        Scene scene = new Scene(pane);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    @FXML
    void owner(ActionEvent event) throws Exception{
        Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/owner_villa.fxml"));
        Scene scene = new Scene(pane);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    @FXML
    void villa(ActionEvent event) throws Exception{
        Parent pane = (AnchorPane) FXMLLoader.load(getClass().getResource("/Villa_admin.fxml"));
        Scene scene = new Scene(pane);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
